# SPH-EXA compatibility and next steps

Reference: https://www.spec.org/cpu2026/Docs/benchmarks/803.sph_exa_s/803.sph_exa_s.html

SPEC names upstream revision 7604c824 as its starting point and says some later changes were incorporated. The archive under `upstream/sph-exa` is unchanged, including its MIT license. The manifest records the full revision and archive hash. Exact SPEC equivalence remains unverified.

## Observed differences to investigate

- Upstream initialization explicitly converts to CGS units. Its sound speed is 3500 cm/s, consistent with the documented 35 m/s; this alone is not a physics difference. Never transplant constants without reconciling units throughout.
- Upstream uses h = 2.5 * dx, dx = 100 / side, mass = 1000000 / particle_count, and initial density 1. SPEC describes fixed smoothing length, mass, and a different initial density. Check units and resolution dependence before changing anything.
- Upstream has ng0=500 (target) and ngmax=650 (capacity); SPEC describes a target of 650. Increasing the target alone may exceed neighbor capacity.
- Upstream writes constants.txt and dump*.txt; SPEC describes CSV and sampling every 128th particle, with validation of intermediate state.
- SPEC removes OpenACC and OpenMP target support. The initial reference build here is serial and disables all accelerator/MPI paths.
- The upstream timestep loop is inclusive: iteration=0 through maxStep. Thus `-s 0` executes a complete update, not merely initialization. The prior chat claim that zero timesteps necessarily leaves evolution untested was incorrect for this source. Verify SPEC loop semantics when reconstructing its driver.
- SPEC describes 15 stabilization steps; its implementation has not been reconstructed.

## Port sequence

1. Freeze serial C++ reference outputs and add high-precision intermediate-state instrumentation separately from upstream.
2. Reproduce initialization in Vine F64, preserving units and precision.
3. Port octree and neighbor traversal; validate sets and order against C++ and a small brute-force oracle.
4. Port density, equation of state, IAD, momentum/energy, timestep selection, position update, and total energy, in source order.
5. Compare complete state after each stage on small valid domains, then multiple updates.
6. Reconstruct documented SPEC workload/output changes separately, with provenance for each change.
7. Measure memory and runtime before attempting the reference scale.

Use n >= 10 for the unmodified initialization's smoothing-length/domain constraint; the smoke case uses n=12. Do not blindly use a tiny 2x2x2 domain.

## Validated pilot scope

Initialization (all 30 fields at sampled particles) and density using upstream-provided neighbor lists pass on sides 12 and 16. This does not yet validate independent neighbor search or time evolution. Preserve computed periodic extent exactly and use the original value/derivative interpolation table. Balanced reductions reorder additions; multistep error growth remains unvalidated. See LESSONS L009–L011.

The retained neighbor-search candidate independently matches all fixed membership cases, including sampled upstream sides12/16, strict radius, self-exclusion, z-periodicity, empty and clustered inputs. Spatial membership is exact; returned order differs and capacity saturation remains outside the initial contract. Performance acceptance still fails, so this is not an accepted integrated neighbor stage. Bounds reduction uses infinity identities internally; all tested physical inputs remain finite.
