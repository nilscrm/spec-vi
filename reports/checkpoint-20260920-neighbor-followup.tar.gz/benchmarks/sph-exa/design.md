# SPH-EXA design decisions

No production representation is chosen yet. Preserve upstream numerical semantics as the initial comparison baseline; document reassociation explicitly. All simulation arithmetic and control belong in Vine; do not hide entire kernels in benchmark-specific native extrinsics.

## Dependency questions

For each stage enumerate input fields, output fields, particle-local operations, neighbor dependencies, global reductions, and dependencies on previous timesteps. Separate necessary physics dependencies from data-structure or traversal ordering.

## Candidates to evaluate

Balanced particle collections; partitioned field access; branching octree construction; independent neighbor queries with measured sharing/copying; balanced local and global reductions. Compare actual compiled depth and resource use before committing to layout.

## Evidence and decisions

Pilot uses balanced value trees for independent particle maps and reductions, and the original 20,000-entry harmonic value/derivative table in Lookup::Size32768. Initialization depth 441 versus serial-fold 826 (32 particles); density 644 versus 1497 (16 queries); work decreased slightly. Evidence and limits: LESSONS L009–L011 and reports/runs/20260915T161128Z-45040/pilot/.

Neighbor construction takes a balanced Tree of unique-id points. Queries depend on the constructed index and their own center/radius; they do not depend on other queries. A spatial hierarchy can prune independent child searches. Construction and index duplication must be included in measurements. Serial insertion and a serial neighbor accumulator are avoidable candidate dependencies. Measure a spatial hierarchy against a trusted serial point scan. Membership is exact, with strict squared-distance comparison and periodic query shifts. Return order can differ; downstream balanced arithmetic requires later multistep validation. Saturating the upstream neighbor capacity is outside this initial contract and must be resolved before full integration.

Initial neighbor hierarchy is rejected for performance: depth3453 versus scan516 at256 points, work growth12.88x for4x size. Exact membership passes. See LESSONS L012 and reports/neighbors/second-candidate/. Next experiments must isolate construction and data duplication costs; the candidate is not accepted for integration.

## Retained follow-up candidate

neighbors.vi now carries bounds/counts with partitions, uses small leaf buckets, infinity identities for empty bounds, and eager pure predicates. At256 particles/queries D1587, W11793450, heap20311232 bytes; full fixed membership cases pass. This improves D54.0% and W19.1% over the initial spatial tree but increases heap24.5%; it still fails the unchanged depth and work-growth gates. It remains experimental and must not advance the physics milestone. Failed scans, reference scans, bottom-up bounds and sampled splits are preserved under reports/neighbors/followup-1/. See L014–L015.

Next dependency question: can queries be routed in batches through an index so that construction, copying and cleanup do not serialize or repeat across all queries? The single-query value API makes broad duplication possible; the shared-root-reference experiment instead creates a long dependency chain. A batch representation needs an explicit output association scheme and the same correctness/resource measurements before adoption.
