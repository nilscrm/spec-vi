# Porting lessons

Use entries with: status (source-confirmed / measured / hypothesis / superseded), context and revisions, observation, evidence or commands, correctness effects, depth/work/memory effects, decision and limits, affected components, and guidance updated. Include raw-result paths for measured claims. Keep durable evidence outside ignored work/ when accepting a milestone.

## L001: Depth instrumentation changes the execution mode

Status: source-confirmed; no performance experiment yet.
Evidence: /Users/nils/repos/vine/cli/src/common.rs, ivm/src/host/runner.rs, and ivm/src/runtime.rs inspected in this session.
Observation: --depth aliases breadth_first; Runner::normalize selects breadth-first before workers; depth counts breadth-first interaction rounds.
Decision: separate depth measurement from parallel timing. Do not interpret depth as elapsed hardware cycles. Applies to every port.
Guidance: PORTING.md measurement contract.

## L002: References and parallelism must be evaluated together

Status: hypothesis requiring measurements.
Observation: avoiding copies alone does not establish low dependency depth. Successive shared-reference access can impose ordering; broad duplication can raise work/memory.
Decision: compare alternatives on representative gather and neighbor-query cases. Do not universally prescribe references or duplication.
Affected components: SPH-EXA data layout, neighbor search, all particle kernels.
Guidance: AGENTS.md acceptance criteria; PORTING.md design hypotheses.

## L003: Read timestep semantics from executable source

Status: source-confirmed for upstream 7604c8241ee3f0e0fa2cf1c0b3c7821c122e0dd6.
Evidence: upstream/sph-exa/src/sqpatch.cpp uses iteration <= maxStep and executes physics within iteration zero.
Correction: -s 0 executes a full update in this upstream revision. It is not initialization-only. Exact SPEC behavior remains unverified.
Guidance: benchmarks/sph-exa/COMPATIBILITY.md; validation must state executed update counts.

## L004: Reconcile units before adapting constants

Status: source-confirmed for the pinned upstream.
Evidence: upstream/sph-exa/src/SqPatch.hpp explicitly converts fields to CGS units.
Observation: 3500 cm/s matches the documented 35 m/s; changing the numeric literal alone would change physics. Other constant and resolution differences remain unresolved.
Guidance: benchmarks/sph-exa/COMPATIBILITY.md.

## L005: Use the upstream release configuration for the initial oracle

Status: observed build failure and successful smoke run in the previous setup cycle.
Evidence: upstream Makefile defines -DNDEBUG; omitting it exposes undeclared names in a debug diagnostic in Domain.hpp. The root Makefile now matches that release define. make sph-exa-smoke ran 1728 particles for iteration labels 0 and 1.
Limits: this is a smoke run, not numerical equivalence validation. Debug diagnostics need a separate documented fix if a debug oracle is required. Raw smoke outputs are currently in work/smoke and are not durable validation fixtures.

## L006: Completion and worker assertions are different states

Status: tested in tests/test_evaluation.py and tests/test_runner.py.
Observation: a process can exit successfully without a valid fresh acceptance report; stale or incomplete milestones must not count as completion.
Decision: require all named milestones, successful gate exit, fresh report, exact milestone identity, and Boolean passed=true. Missing gates produce waiting, not complete. Worker claims do not override the gate, and changes to acceptance inputs stop the run.
Guidance: docs/RUNNER.md and the runner implementation. These checks establish orchestration integrity; scientific acceptance still depends on the quality of registered gates.

## L007: Check the compiled environment and explicit imports

Status: measured infrastructure probe; reports/runs/20260914T031302Z-28405/bootstrap/.
Observation: Array was not available unqualified in the probe. Importing #root::data::Array made the test compile. The existing release binary produced the expected 64 with --depth and separately with two workers.
Limits: binary hash identifies the executable, but a source revision alone does not prove an existing binary incorporates local modifications. This is no evidence of SPH performance or optimality.
Guidance: docs/RUNNER.md provenance limits; SPH evaluator must establish matching build provenance before interpreting optimization comparisons.

## L008: Superseded dirty builds are not supported dependencies

Status: user correction and source-confirmed audit, 2026-09-15.
The user stashed earlier local Vine changes. work/vine-source contains them, including facilities referenced by the partial pilot; it must not supply acceptance evidence for the new toolchain. origin/lookup at 7cf26c3e provides the preferred static lookup mechanism.
Decision: use an isolated lookup-based revision and independently tested generic library additions. Revalidate initialization and density after updating the dependency.
Guidance: docs/VINE_CHANGES.md and AGENTS.md.

## L009: Measure the numerical kernel without serial decimal formatting

Status: measured on lookup 7cf26c3e plus isolated support changes.
Evidence: reports/runs/20260915T161128Z-45040/pilot/result.json and generated drivers.
Full 30-field initialization and density outputs passed at fixed atol=1e-9, rtol=5e-12 on sides 12 and 16. Largest absolute initialization error was 4.3655745685100555e-11; density error was at most 1.11e-15. Balanced reductions reduced initialization depth from 826 to 441 for 32 particles and density depth from 1497 to 644 for 16 queries, with slightly lower work in both. These are local kernel experiments, not timestep or hardware throughput results.
Decision: retain full numerical output for correctness; force all fields with a balanced checksum and emit its two integer bit halves for depth. Decimal F64 formatting otherwise dominates the observed path. Validate that checksum independently too. Reassociation still needs multistep error checks.

## L010: Preserve computed geometry at lookup boundaries

Status: measured, same toolchain and pilot evidence as L009.
Replacing the computed periodic bounding-box extent by the algebraically expected 100 caused density differences around 1e-9. Passing the exact upstream bbox.zmax-bbox.zmin reduced these to machine precision. Turning off C++ FMA contraction alone did not resolve this discrepancy.
Decision: preserve floating-point operation order and computed geometry when lookup indices or strict geometric predicates depend on rounding. Do not widen tolerance to hide a discontinuity. Neighbor search must reproduce shifted-query arithmetic, not assume all periodic-distance formulas round identically.

## L011: Static table compilation has a stack cost

Status: measured with the 20,000-entry harmonic table and tests/programs/lookup_large.vi.
The default compiler process stack overflowed. tools/vine_exec.py uses a bounded 65,520 KiB stack via zsh before exec; the large lookup test then passed. Python setrlimit rejected this limit on this host, so the wrapper uses an argv-preserving shell invocation. Root Lookup was extended through Size32768 with explicit bounds checks; negative bounds tests fail as intended.
Decision: record compiler and runtime resource costs separately. Per-command RSS currently covers compilation plus execution. This stack workaround is not evidence of a runtime depth improvement; an upstream compiler-stack improvement remains a possible follow-up.

## L012: Spatial partitioning can cost more depth than a scan

Status: measured failed candidate, reports/neighbors/second-candidate/result.json.
The balanced midpoint spatial hierarchy passes eight membership cases including upstream sides12/16, exact radius, coincident points, z-periodicity, empty and shuffled clustered data. At64 points/queries it uses depth2120, work1,131,885; at256 it uses depth3453, work14,576,282. The trusted serial scan uses depth393/516 and work993,221/16,012,579 respectively. Candidate work grows12.88x for4x size, exceeding the fixed10x ceiling; depth also fails the required0.7 baseline ratio. Two-worker runtime at256 was138ms (process time includes compilation and was1.22s). This is a rejected candidate, not an optimization success.
Decision: measure construction, repeated bounds computation, partition/compaction and index duplication separately before choosing a more complex representation. The baseline's source-level accumulator does not imply measured linear depth: compiled dependency behavior is the authority. Fixed acceptance budgets remain unchanged. Vine logical syntax is `and`/`or`; use boolean bitwise operators only deliberately when eager parallel evaluation is desired.
Guidance: design.md and NEIGHBOR_WORKER.md. Generality and unsaturated membership only; output order/capacity and timestep checks remain pending.

## L013: Test real worker tool execution before claiming unattended work

Status: measured environment limitation, reports/worker-preflight2.stdout and .stderr.
Initial CLI startup failed on state database writes. Granted normal Codex state access enabled a model response, but its Node tool process could not start under the nested sandbox. Exit0 did not mean file access or implementation succeeded. No worker code changes occurred.
Decision: keep workspace sandboxing; stop blind CLI retries. The installed Continue SPH-EXA Vine port heartbeat resumes implementation directly in the existing task and uses the independent runner without --port. Model connectivity and actual tool execution are separate readiness checks. Acceptance remains independent of agent claims.

## L014: Cache partition summaries and separate pure predicates

Status: measured on the same pinned Vine toolchain; reports/neighbors/eager-cached-validation/result.json, plus reproducible probes under reports/neighbors/followup-1/.
Build-only consumption of all particle identities in the original hierarchy has depth1616/2835 at64/256 points, versus full build/query depth2120/3453. This probe discards final bounding metadata, so it is a lower-cost construction diagnostic, not a separable timing to subtract from full depth.
Changes: return counts/bounds alongside partitions rather than traverse both resulting trees again; keep small leaf buckets instead of additional bounding hierarchies; use infinities as the empty min/max reduction identity, removing count-dependent branches; evaluate total, pure geometric predicates with boolean bitwise operations. No spatial arithmetic reassociation or tolerance change was introduced.
Best full results at64/256: D1006/1587, W892378/11793450, heap1948912/20311232 bytes. At256 this lowers depth54.0% and work19.1% versus the original hierarchy. Heap rises from16318720 to20311232 bytes (24.5%); the depth reduction is not free. The cached-only intermediate used D1956 and heap17270976 at256; pure predicate/identity changes trade more live memory for lower depth.
All eight fixed membership cases pass, including upstream sides12/16. Depth/work acceptance still FAILS: required maximum depth361.2 versus observed1587; work growth13.22x exceeds10x. Do not label this milestone complete. Separate two-worker logs are retained; short timings are observations, not stable speedup claims.
Rejected probes: an eager parallel scan D506/W15507232 at256 with16.08x work growth; an unpartitioned bottom-up bounding tree D1146/W22481128; sampled splitting D3542/W11093894. Probe aggregate checksums match the oracle, but only the retained candidate has full membership validation. Keep the fixed budgets and evidence.
Guidance: PORTING.md and benchmark design/plan. Next investigate data routing and construction together, not another serial split heuristic.

## L015: Shared references reduced work but serialized the queries

Status: measured controlled scan comparison, reports/neighbors/followup-1/ref-scan/ versus scan-eager/.
Replacing the value tree by a shared reference in the otherwise equivalent eager scan reduces256-particle work from15507232 to9588962, but increases depth506 to6661. At64 particles depth is1797. Aggregate outputs agree with the brute-force oracle. This confirms the L002 risk for this access pattern; it is not a prohibition on references generally.
Decision: do not adopt a shared root reference for independent neighbor queries. Compare batched spatial routing or a purpose-built immutable access representation, including construction and cleanup, before proposing reusable Vine capabilities. Such alternatives are untested hypotheses. Changing a driver to permit batched queries would require a separately justified evaluator review preserving inputs, full output checks and budgets; it must not silently relax acceptance.

Follow-up validation for L014: five additional cases (64 coincident points, 96 collinear points, and three deterministic random periodic clouds) pass exact membership in reports/neighbors/eager-cached-extra/. The unchanged pilot passes again in reports/pilot/neighbor-followup-regression/result.json, including separate two-worker checks. All17 infrastructure/oracle tests pass. No full-timestep or hardware acceptance is implied.
