# Porting lessons

Use entries with: status (source-confirmed / measured / hypothesis / superseded), context and revisions, observation, evidence or commands, correctness effects, depth/work/memory effects, decision and limits, affected components, and guidance updated. Include raw-result paths for measured claims. Keep durable evidence outside ignored work/ when accepting a milestone.

## L001: Depth instrumentation changes the execution mode

Status: source-confirmed; no performance experiment yet.
Evidence: /Users/nils/repos/vine/cli/src/common.rs, ivm/src/host/runner.rs, and ivm/src/runtime.rs inspected in this session.
Observation: --depth aliases breadth_first; Runner::normalize selects breadth-first before workers; depth counts breadth-first interaction rounds.
Decision: separate depth measurement from parallel timing. Do not interpret depth as elapsed hardware cycles. Applies to every port.
Guidance: PORTING.md measurement contract.

## L002: References and parallelism must be evaluated together

Status: hypothesis requiring measurements.
Observation: avoiding copies alone does not establish low dependency depth. Successive shared-reference access can impose ordering; broad duplication can raise work/memory.
Decision: compare alternatives on representative gather and neighbor-query cases. Do not universally prescribe references or duplication.
Affected components: SPH-EXA data layout, neighbor search, all particle kernels.
Guidance: AGENTS.md acceptance criteria; PORTING.md design hypotheses.

## L003: Read timestep semantics from executable source

Status: source-confirmed for upstream 7604c8241ee3f0e0fa2cf1c0b3c7821c122e0dd6.
Evidence: upstream/sph-exa/src/sqpatch.cpp uses iteration <= maxStep and executes physics within iteration zero.
Correction: -s 0 executes a full update in this upstream revision. It is not initialization-only. Exact SPEC behavior remains unverified.
Guidance: benchmarks/sph-exa/COMPATIBILITY.md; validation must state executed update counts.

## L004: Reconcile units before adapting constants

Status: source-confirmed for the pinned upstream.
Evidence: upstream/sph-exa/src/SqPatch.hpp explicitly converts fields to CGS units.
Observation: 3500 cm/s matches the documented 35 m/s; changing the numeric literal alone would change physics. Other constant and resolution differences remain unresolved.
Guidance: benchmarks/sph-exa/COMPATIBILITY.md.

## L005: Use the upstream release configuration for the initial oracle

Status: observed build failure and successful smoke run in the previous setup cycle.
Evidence: upstream Makefile defines -DNDEBUG; omitting it exposes undeclared names in a debug diagnostic in Domain.hpp. The root Makefile now matches that release define. make sph-exa-smoke ran 1728 particles for iteration labels 0 and 1.
Limits: this is a smoke run, not numerical equivalence validation. Debug diagnostics need a separate documented fix if a debug oracle is required. Raw smoke outputs are currently in work/smoke and are not durable validation fixtures.

## L006: Completion and worker assertions are different states

Status: tested in tests/test_evaluation.py and tests/test_runner.py.
Observation: a process can exit successfully without a valid fresh acceptance report; stale or incomplete milestones must not count as completion.
Decision: require all named milestones, successful gate exit, fresh report, exact milestone identity, and Boolean passed=true. Missing gates produce waiting, not complete. Worker claims do not override the gate, and changes to acceptance inputs stop the run.
Guidance: docs/RUNNER.md and the runner implementation. These checks establish orchestration integrity; scientific acceptance still depends on the quality of registered gates.

## L007: Check the compiled environment and explicit imports

Status: measured infrastructure probe; reports/runs/20260914T031302Z-28405/bootstrap/.
Observation: Array was not available unqualified in the probe. Importing #root::data::Array made the test compile. The existing release binary produced the expected 64 with --depth and separately with two workers.
Limits: binary hash identifies the executable, but a source revision alone does not prove an existing binary incorporates local modifications. This is no evidence of SPH performance or optimality.
Guidance: docs/RUNNER.md provenance limits; SPH evaluator must establish matching build provenance before interpreting optimization comparisons.

## L008: Superseded dirty builds are not supported dependencies

Status: user correction and source-confirmed audit, 2026-09-15.
The user stashed earlier local Vine changes. work/vine-source contains them, including facilities referenced by the partial pilot; it must not supply acceptance evidence for the new toolchain. origin/lookup at 7cf26c3e provides the preferred static lookup mechanism.
Decision: use an isolated lookup-based revision and independently tested generic library additions. Revalidate initialization and density after updating the dependency.
Guidance: docs/VINE_CHANGES.md and AGENTS.md.

## L009: Measure the numerical kernel without serial decimal formatting

Status: measured on lookup 7cf26c3e plus isolated support changes.
Evidence: reports/runs/20260915T161128Z-45040/pilot/result.json and generated drivers.
Full 30-field initialization and density outputs passed at fixed atol=1e-9, rtol=5e-12 on sides 12 and 16. Largest absolute initialization error was 4.3655745685100555e-11; density error was at most 1.11e-15. Balanced reductions reduced initialization depth from 826 to 441 for 32 particles and density depth from 1497 to 644 for 16 queries, with slightly lower work in both. These are local kernel experiments, not timestep or hardware throughput results.
Decision: retain full numerical output for correctness; force all fields with a balanced checksum and emit its two integer bit halves for depth. Decimal F64 formatting otherwise dominates the observed path. Validate that checksum independently too. Reassociation still needs multistep error checks.

## L010: Preserve computed geometry at lookup boundaries

Status: measured, same toolchain and pilot evidence as L009.
Replacing the computed periodic bounding-box extent by the algebraically expected 100 caused density differences around 1e-9. Passing the exact upstream bbox.zmax-bbox.zmin reduced these to machine precision. Turning off C++ FMA contraction alone did not resolve this discrepancy.
Decision: preserve floating-point operation order and computed geometry when lookup indices or strict geometric predicates depend on rounding. Do not widen tolerance to hide a discontinuity. Neighbor search must reproduce shifted-query arithmetic, not assume all periodic-distance formulas round identically.

## L011: Static table compilation has a stack cost

Status: measured with the 20,000-entry harmonic table and tests/programs/lookup_large.vi.
The default compiler process stack overflowed. tools/vine_exec.py uses a bounded 65,520 KiB stack via zsh before exec; the large lookup test then passed. Python setrlimit rejected this limit on this host, so the wrapper uses an argv-preserving shell invocation. Root Lookup was extended through Size32768 with explicit bounds checks; negative bounds tests fail as intended.
Decision: record compiler and runtime resource costs separately. Per-command RSS currently covers compilation plus execution. This stack workaround is not evidence of a runtime depth improvement; an upstream compiler-stack improvement remains a possible follow-up.

## L012: Spatial partitioning can cost more depth than a scan

Status: measured failed candidate, reports/neighbors/second-candidate/result.json.
The balanced midpoint spatial hierarchy passes eight membership cases including upstream sides12/16, exact radius, coincident points, z-periodicity, empty and shuffled clustered data. At64 points/queries it uses depth2120, work1,131,885; at256 it uses depth3453, work14,576,282. The trusted serial scan uses depth393/516 and work993,221/16,012,579 respectively. Candidate work grows12.88x for4x size, exceeding the fixed10x ceiling; depth also fails the required0.7 baseline ratio. Two-worker runtime at256 was138ms (process time includes compilation and was1.22s). This is a rejected candidate, not an optimization success.
Decision: measure construction, repeated bounds computation, partition/compaction and index duplication separately before choosing a more complex representation. The baseline's source-level accumulator does not imply measured linear depth: compiled dependency behavior is the authority. Fixed acceptance budgets remain unchanged. Vine logical syntax is `and`/`or`; use boolean bitwise operators only deliberately when eager parallel evaluation is desired.
Guidance: design.md and NEIGHBOR_WORKER.md. Generality and unsaturated membership only; output order/capacity and timestep checks remain pending.

## L013: Test real worker tool execution before claiming unattended work

Status: measured environment limitation, reports/worker-preflight2.stdout and .stderr.
Initial CLI startup failed on state database writes. Granted normal Codex state access enabled a model response, but its Node tool process could not start under the nested sandbox. Exit0 did not mean file access or implementation succeeded. No worker code changes occurred.
Decision: keep workspace sandboxing; stop blind CLI retries. The installed Continue SPH-EXA Vine port heartbeat resumes implementation directly in the existing task and uses the independent runner without --port. Model connectivity and actual tool execution are separate readiness checks. Acceptance remains independent of agent claims.

## L014: Cache partition summaries and separate pure predicates

Status: measured on the same pinned Vine toolchain; reports/neighbors/eager-cached-validation/result.json, plus reproducible probes under reports/neighbors/followup-1/.
Build-only consumption of all particle identities in the original hierarchy has depth1616/2835 at64/256 points, versus full build/query depth2120/3453. This probe discards final bounding metadata, so it is a lower-cost construction diagnostic, not a separable timing to subtract from full depth.
Changes: return counts/bounds alongside partitions rather than traverse both resulting trees again; keep small leaf buckets instead of additional bounding hierarchies; use infinities as the empty min/max reduction identity, removing count-dependent branches; evaluate total, pure geometric predicates with boolean bitwise operations. No spatial arithmetic reassociation or tolerance change was introduced.
Best full results at64/256: D1006/1587, W892378/11793450, heap1948912/20311232 bytes. At256 this lowers depth54.0% and work19.1% versus the original hierarchy. Heap rises from16318720 to20311232 bytes (24.5%); the depth reduction is not free. The cached-only intermediate used D1956 and heap17270976 at256; pure predicate/identity changes trade more live memory for lower depth.
All eight fixed membership cases pass, including upstream sides12/16. Depth/work acceptance still FAILS: required maximum depth361.2 versus observed1587; work growth13.22x exceeds10x. Do not label this milestone complete. Separate two-worker logs are retained; short timings are observations, not stable speedup claims.
Rejected probes: an eager parallel scan D506/W15507232 at256 with16.08x work growth; an unpartitioned bottom-up bounding tree D1146/W22481128; sampled splitting D3542/W11093894. Probe aggregate checksums match the oracle, but only the retained candidate has full membership validation. Keep the fixed budgets and evidence.
Guidance: PORTING.md and benchmark design/plan. Next investigate data routing and construction together, not another serial split heuristic.

## L015: Shared references reduced work but serialized the queries

Status: measured controlled scan comparison, reports/neighbors/followup-1/ref-scan/ versus scan-eager/.
Replacing the value tree by a shared reference in the otherwise equivalent eager scan reduces256-particle work from15507232 to9588962, but increases depth506 to6661. At64 particles depth is1797. Aggregate outputs agree with the brute-force oracle. This confirms the L002 risk for this access pattern; it is not a prohibition on references generally.
Decision: do not adopt a shared root reference for independent neighbor queries. Compare batched spatial routing or a purpose-built immutable access representation, including construction and cleanup, before proposing reusable Vine capabilities. Such alternatives are untested hypotheses. Changing a driver to permit batched queries would require a separately justified evaluator review preserving inputs, full output checks and budgets; it must not silently relax acceptance.

Follow-up validation for L014: five additional cases (64 coincident points, 96 collinear points, and three deterministic random periodic clouds) pass exact membership in reports/neighbors/eager-cached-extra/. The unchanged pilot passes again in reports/pilot/neighbor-followup-regression/result.json, including separate two-worker checks. All17 infrastructure/oracle tests pass. No full-timestep or hardware acceptance is implied.

## L016: Batched routing removes repeated index work, but compaction adds depth

Status: measured isolated experiment; reports/neighbors/batch-routing/ and batch-routing-uncompacted/. Production candidate, toolchain and acceptance gates are unchanged. Both variants pass all eight fixed full-membership cases, including unchanged upstream side12/16 fixtures; the compacted variant also passes empty-query, coincident64 and three random periodic cloud cases. Full output checks, checksum forcing, source hashes and exact commands are preserved. Separate two-worker runs pass. No milestone is accepted.

Implementation: prepare each query with its own negative-polarity result connection, then traverse the spatial index once while routing request subsets to children. Results retain their original query identities without a serial merge. This uses existing Vine facilities, not a native neighbor kernel or shared mutable root reference.

Compacted routing at64/256: depth1037/1596, work543199/4294285, heap1180720/7557088 bytes. Matched-library single-query controls reproduce depth1006/1587, work892378/11793450, heap1948912/20311232. Thus256-point work falls63.6% and heap62.8%, with slightly higher depth. Work growth7.91x now meets the unchanged10x ceiling. The depth limit361.2 still fails. budget-review.json records each original criterion explicitly; no acceptance policy was changed.

Removing request compaction gives depth998/1579 but work844335/10897175, growth12.91x: the small depth gain loses the required work scaling. Do not adopt this variant as a solution.

Query-only diagnostics prebuild the same index outside Vine solely to isolate access. At256, compacted batching has depth1229 versus single-query629; uncompacted batching558. These runs exclude required construction and are not acceptance evidence. They show that request compaction itself delays traversal; it is inaccurate to attribute the full compacted run's depth solely to construction. Do not subtract diagnostic depths from full depth.

Decision: retain compacted batching as a validated experimental API option, without replacing the failed production gate. Next investigate tiled routing (compact between fixed-size query groups, retain structure within groups), and independently reduce construction depth. A gate extension for batched input needs a separate review preserving all fixtures, output association/forcing, budgets, and the single-query correctness checks. Do not replay broad shared-root references or globally uncompacted routing without a new hypothesis.

Comparison limit: the isolated library omits unrelated pilot/table modules, so its process RSS and compile time cannot be compared directly with the full production library. Runtime interaction/depth/heap controls use the same isolated library and reproduce the prior values.

## L017: Coarse request compaction did not remove the depth bottleneck

Status: measured rejected variants, reports/neighbors/tiled-routing/{results,review}.json; exact source/drivers and hashes are preserved. No production/shared code or acceptance input changed.
An occupancy Bool reduction compacted request structure every1/2/3/4 tree levels, retaining holes between compacting levels. All four variants pass full membership at the fixed64/256 scaling cases. At256, (D,W) are (1629,7270948), (1593,8276168), (1584,8346762), (1579,10700502). Their work growth factors are9.67/10.29/9.77/13.31. Compared with compacted batching's D1596/W4294285, stride3 saves only12 rounds while nearly doubling work. Reject this tradeoff; do not promote any variant or broaden performance testing without a new hypothesis.
Vine correctly rejected implicitly dropping request trees containing negative-polarity output connections. The implementation explicitly drains trees in occupancy-false branches. Include that cleanup in work/depth; never use unsafe erasure to make logically empty but linearly typed data disappear.

Construction diagnostics in tiled-routing/construction/results.json show depth789/1286 at64/256 for the retained builder while consuming all particle identities, and bounds-only depth348/374 while consuming all six coordinates. These diagnostics have different consumers and omit final bounding-metadata consumption in the builder case. They cannot be subtracted from total depth or treated as a formal bound for a different consumer. They do show that another small routing change is unlikely to resolve the full depth target on this builder.
Decision: keep L016's compacted batch experiment as the work-efficient candidate. Next isolate scalar min/max selection, aggregate copying, and recursive partition construction; compare a bottom-up radix/bucket construction that avoids successive whole-subtree bounds/partition dependencies. Extend Vine only for a measured reusable scalar/collection gap, with standalone tests and a new pin. No budget relaxation or milestone advancement.

## L018: Spatial-key construction exposed a sequential root primitive

Status: source-confirmed and measured; reports/neighbors/radix-builder/, radix-fixed-bits/, radix-buckets/, independent-buckets/, builder-costs/ and reports/vine/clz/.
The bottom-up Morton prototype computes keys independently, merges compressed radix trees, then derives exact bounds. All eight fixed membership cases pass, but its256-point depth5366 loses to the retained compacted builder/query pipeline1596. Vine N32.leading_zeros scanned bits in a loop; substituting five fixed shift/OR rounds for highest-bit selection reduces radix depth to3056. Coalescing subtrees of at most8 particles reduces it to2809, still rejected. Key collisions retain all points, so quantization changes grouping only, not membership. Independent coarse buckets also fail to improve the overall tradeoff:8 cells give D1685/W5622354 at256 and64 cells D1954/W6349941 (both scaling cases passed full membership). Do not promote these builders.

Reusable finding: do not assume a scalar library operation has constant shallow implementation from its name. The existing leading_zeros also serves N64 and Nat division. A five-step binary search preserves zero->32 and all bit-count semantics. Independent Python bit_length vectors cover1118 boundary/random words; prototype batches reduce D238->74 for one high-bit word, D301->140 for32 mixed words, and D377->216 for1118 words. At1118, work286129->56217; live heap253488->579584 bytes. This trades higher parallel live memory for fewer dependencies and much less work. A separate highest-bit implementation passes1118 independent vectors.

The root-only leading_zeros change is now in isolated work/vine-lookup, with a standalone1118-vector Vine test and passing N64 division, Nat division/edge, F64 operations and sine regression output comparisons. Patch dependencies/vine/0003-bounded-leading-zeros.patch preserves it with snapshot updates. The executable is unchanged because it loads root sources when compiling; source hashes/pin distinguish this toolchain. Integrated revalidation completed in reports/runs/20260921T190441Z-95573: bootstrap and pilot pass; all eight neighbor memberships pass, with unchanged failing depth1587 versus limit361.2 and work growth13.22x. The dependency pin is validated; the neighbor milestone is not accepted. Actual root-function measurements in reports/vine/clz/root-after.json exactly reproduce the prototype depth/work/heap above, using the original drivers and identical outputs. Earlier measurements remain attached to the old root snapshot/pin; do not compare mixed-toolchain results as builder improvements.

## L019: Separate coordinate trees and deferred partition summaries lost depth

Status: rejected matched diagnostics under the validated CLZ pin; reports/neighbors/bounds-layout/{run,routing,exact}.py and {result,routing,exact}.json. These are component diagnostics, not neighbor acceptance or formal depth lower bounds. Every depth consumer forces six bounds, counts and particle identity checksums. Separate exact checks compare both F64 bit halves of every bound and every routed identity in order against Python expectations at64/256. Conversion, copying and cleanup are included.

Bounds layouts at64/256: existing aggregate D415/465, W17122/67426; six independent scalar reductions D493/541, W51129/203769; three coordinate-pair reductions D473/521, W35706/141690. At256 heap is512432/504608/398304 bytes respectively. Splitting fields into separate trees does not automatically expose a shallower graph: conversion and duplicated traversals can outweigh independence. Both alternatives are rejected before integration.

Fixed x-midpoint routing at64/256: cached summaries D388/430, W23863/94884; route then recompute bounds D521/600, W19625/78166. At256 deferred summaries lower work17.6% and heap992544->398096 bytes but raise depth39.5%. Keep cached summaries. These compare a fixed axis/split only and do not cover adaptive axis choice or full builder behavior.

No production source, root dependency or acceptance policy changed. No milestone advanced and no integrated rerun was warranted. Next isolate structural compaction in point partitioning: compare cached summaries with compacting join versus structure-preserving branches, including both partition and full builder/query costs. This differs from previously rejected query-request compaction variants; predict increased work from empty point branches and reject promptly if it breaches the fixed budgets.
