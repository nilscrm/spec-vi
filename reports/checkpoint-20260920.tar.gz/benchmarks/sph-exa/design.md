# SPH-EXA design decisions

No production representation is chosen yet. Preserve upstream numerical semantics as the initial comparison baseline; document reassociation explicitly. All simulation arithmetic and control belong in Vine; do not hide entire kernels in benchmark-specific native extrinsics.

## Dependency questions

For each stage enumerate input fields, output fields, particle-local operations, neighbor dependencies, global reductions, and dependencies on previous timesteps. Separate necessary physics dependencies from data-structure or traversal ordering.

## Candidates to evaluate

Balanced particle collections; partitioned field access; branching octree construction; independent neighbor queries with measured sharing/copying; balanced local and global reductions. Compare actual compiled depth and resource use before committing to layout.

## Evidence and decisions

Pilot uses balanced value trees for independent particle maps and reductions, and the original 20,000-entry harmonic value/derivative table in Lookup::Size32768. Initialization depth 441 versus serial-fold 826 (32 particles); density 644 versus 1497 (16 queries); work decreased slightly. Evidence and limits: LESSONS L009–L011 and reports/runs/20260915T161128Z-45040/pilot/.

Neighbor construction takes a balanced Tree of unique-id points. Queries depend on the constructed index and their own center/radius; they do not depend on other queries. A spatial hierarchy can prune independent child searches. Construction and index duplication must be included in measurements. Serial insertion and a serial neighbor accumulator are avoidable candidate dependencies. Measure a spatial hierarchy against a trusted serial point scan. Membership is exact, with strict squared-distance comparison and periodic query shifts. Return order can differ; downstream balanced arithmetic requires later multistep validation. Saturating the upstream neighbor capacity is outside this initial contract and must be resolved before full integration.

Initial neighbor hierarchy is rejected for performance: depth3453 versus scan516 at256 points, work growth12.88x for4x size. Exact membership passes. See LESSONS L012 and reports/neighbors/second-candidate/. Next experiments must isolate construction and data duplication costs; the candidate is not accepted for integration.
