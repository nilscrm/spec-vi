# SPH-EXA execution plan

## Status

- Done: pinned unchanged upstream, source manifest, serial C++ build and smoke run.
- Done: persistent workflow and mandatory documentation learning loop.
- Done: local status runner, bootstrap gate, table comparator, stats parser, and runtime diagnostic probe.
- Done: high-precision initialization/density pilot on sides 12 and 16, fixed correctness/depth/work/heap budgets. Evidence: reports/runs/20260915T161128Z-45040/pilot/.
- Done: bounded optional Codex worker dispatch and independent re-verification; tested with mocked workers only.
- Neighbor gate is registered. Initial candidate passes membership but fails depth/work scaling (L012); runner status is authoritative for worker activity.

## Toolchain transition

work/vine-lookup is the isolated lookup-based checkout with tested scalar sine/pi and large bounded lookup additions. Main Vine and stashes remain untouched. Support changes are staged; signed commits were blocked by unavailable GPG agent access. Preserve patches and exact source/binary hashes until checkpoint signing is available.

## Next action

Implement independent neighbor membership checks against upstream and brute force, including strict-radius, self-exclusion, periodic, empty and clustered cases. Measure complete construction plus batched queries against a trusted serial scan; preserve work/heap budgets. Register the gate, then implement and validate the candidate. Neighbor iteration order and capacity saturation remain explicit integration questions.

## Milestones

1. Evaluator: fixed valid cases, numerical policy, structured results, resource limits, depth driver that forces all outputs, separate parallel timing.
2. Initialization and density pilot: full dependency argument, C++ comparisons, multiple input sizes, measured alternative formulations, learned guidance updates.
3. Octree construction and neighbor search: brute-force small-case oracle plus upstream sets/order comparison; clustered and boundary cases.
4. Density, equation of state, IAD, momentum/energy, timestep selection, position update, total energy. Implement prerequisites needed for the density pilot before claiming the pilot complete.
5. Integrated update and multiple updates: intermediate states, error growth, depth/work/memory scaling.
6. Reconstruct documented SPEC-like driver/output behavior, keeping unresolved differences explicit.
7. Full selected workload validation and parallel hardware measurements. Record any workloads not executed; do not call the full port validated without them.
8. Enable unattended milestone execution only after the pilot demonstrates reliable evaluator acceptance and checkpoint recovery.

For each milestone record candidate, evidence paths, numerical results, depth/work/memory, dependency rationale, changed Markdown files (or no new lessons), and next action. Reopen affected completed components when new evidence invalidates assumptions.

## Continuation status (2026-09-20)

Pilot revalidated with separate two-worker runs: reports/runs/20260920T180935Z-79500/pilot/result.json. Neighbor membership passes but depth/work gates fail. A real nested CLI worker cannot start its tool sandbox; no CLI implementation worker is active. Continue directly in the existing Codex task via the installed30-minute heartbeat; run acceptance without --port. Do not keep retrying nested workers or relax sandboxing. Next: isolate bounds/partition/copying costs and compare simpler eager-predicate representations. Preserve the failure and unchanged budgets.
