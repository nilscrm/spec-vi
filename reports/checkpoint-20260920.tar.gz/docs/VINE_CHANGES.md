# Coordinating Vine changes with SPEC ports

## Repository boundary

Reusable numerical operations, collection APIs, lookup mechanisms, and runtime/compiler fixes belong in Vine. Benchmark constants, SPH equations, data layouts, and compatibility adaptations belong in spec-vi. Do not hide benchmark kernels in native extrinsics to reduce measured depth.

## Isolation and pins

Use an isolated Vine checkout based on the user-selected lookup branch (locally origin/lookup at 7cf26c3e on 2026-09-15). Leave the main checkout, stashes, and untracked files untouched. Pin an exact commit, not a moving branch. Make one focused library change per commit. Prepare changes for upstream review without automatically publishing or merging them.

## Capability workflow

1. Record the missing operation, SPH call sites, and smallest reusable API in the active plan. Inspect existing facilities first.
2. Specify precision, rounding/error expectations, numerical boundary behavior, and expected work/depth/memory scaling.
3. Implement it in isolated Vine, with standalone numerical and boundary tests plus depth tests for growing batches of independent calls. Follow Vine's own contributor instructions and run its relevant checks.
4. Rebuild and validate the affected SPH kernels on that exact revision. Only then update the spec-vi dependency pin.
5. Record source and binary hashes, root library, build options, and before/after results. Keep old measurements; do not silently rewrite baselines or compare implementations on different runtimes.
6. Update lessons, general porting guidance, benchmark design, and API documentation with evidence and limits. Track library dependencies explicitly as milestones.

The candidate worker must not weaken the numerical oracle or acceptance budgets. Legitimate evaluator changes need a separate rationale and regression tests, not automatic acceptance of changed checks.

## Current transition

The user stashed the tracked local Vine edits. The previously built work/vine-source snapshot contains those edits and is superseded for future acceptance. Existing untracked files in the main checkout must not be silently imported.

The initialization/density pilot passed on the isolated lookup checkout with deliberate F64::pi/sin additions and bounded static lookup support. Evidence: reports/runs/20260915T161128Z-45040/pilot/. Support changes are staged; signed checkpoint creation was blocked by unavailable GPG agent access. The main checkout remains untouched.

origin/lookup provides static O(log n) lookup and Array::even_odd. Named sizes stop at Size4096; the 20000-entry SPH table needs a sufficient bound, such as 32768, with bounds behavior and build/code-size measurements. Generic size support belongs in Vine; generated table values and the original SPH interpolation formula belong in spec-vi. The earlier per-query trig reconstruction is an experiment superseded by the selected lookup strategy.
