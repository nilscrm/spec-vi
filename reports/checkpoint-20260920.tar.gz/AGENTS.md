# spec-vi working instructions

## Objective and scope

Port applications used by SPEC to clear, idiomatic Vine with numerical correctness and low unnecessary dependency depth. Start with the complete square-patch computational workload of SPH-EXA. Source compatibility is described in benchmarks/sph-exa/COMPATIBILITY.md; upstream MPI and accelerator backends are not separate Vine port targets unless requested.

Read docs/PORTING.md, docs/VINE_CHANGES.md, docs/LESSONS.md, and the active benchmark's plan.md, design.md, and COMPATIBILITY.md before implementation. Resume from the recorded next action and evidence; do not restart completed work.

## Non-negotiable acceptance criteria

- Keep upstream sources and licenses unchanged. Put reference instrumentation and adaptations in separate files or reproducible patches.
- Preserve fixed correctness tolerances and validation coverage. Never weaken checks, change expected outputs, omit computation, or shrink benchmark inputs just to accept a candidate.
- Optimize critical-path depth subject to correctness, work, and memory budgets. Record depth, interactions, memory, and numerical error across input sizes. Measure actual parallel timing separately.
- Before implementing a component, describe its data dependencies, necessary sequential operations, expected work/depth scaling, and how outputs are forced during measurement.
- Measure alternative representations when shared references, copying, indexing, construction, reduction, or cleanup could dominate depth. A reference avoids some copying but does not prove independent execution.
- Floating-point reassociation must be documented and validated across multiple timesteps. Preserve the original oracle; use a separate reference variant to investigate changed reduction order.
- Record the Vine revision AND local modifications, compiler options, exact input and command for reproducible experiments. Do not overwrite user changes in /Users/nils/repos/vine.
- Compilation, an isolated output checksum, or a self-reported completion message does not establish completion. Require evaluator evidence and integrated validation.

## Mandatory learning loop

Whenever an experiment, failure, source inspection, review, or user correction teaches a better way to port code, update the Markdown guidance in the SAME work cycle, before marking the component complete or moving to the next component.

1. Record the observation, provenance, hypothesis, experiment commands, numerical and performance results, and applicable limits in docs/LESSONS.md. Mark untested ideas as hypotheses.
2. Promote reusable, supported techniques into docs/PORTING.md. Change AGENTS.md only for durable project-wide requirements; keep it concise.
3. Update benchmark design.md for representation/dependency decisions, COMPATIBILITY.md for source or numerical semantics, and plan.md for progress and the next action.
4. Correct superseded guidance in place and point to the evidence explaining the correction. Do not leave conflicting instructions for future runs.
5. If a lesson affects an already completed component, add a concrete re-evaluation task to plan.md and identify which checks must be repeated.
6. Do not infer universal rules from one workload or one measurement. Record tradeoffs and failed approaches so they are not repeated without new evidence.

Documentation updates are part of the definition of done. If a cycle yields no new lesson, explicitly record that in the experiment report; do not invent a lesson or churn guidance. Knowledge updates must not relax the objective, correctness policy, or acceptance budgets to accommodate a failing candidate.

## Checkpoint protocol

At every accepted milestone, preserve commands and machine-readable results, update the plan, summarize remaining risks, and write a concrete next action. Keep failed candidates' useful evidence. A supervisor must independently verify acceptance; agent prose is not a test result.

## Vine dependencies

Follow docs/VINE_CHANGES.md for missing root/runtime capabilities. Use an isolated lookup-based checkout; never restore stashed changes implicitly. Keep reusable additions in focused Vine commits with semantic and depth tests, then pin and validate the resulting toolchain in spec-vi. Do not accept mixed-toolchain comparisons as performance improvements. Record library blockers and lessons in the active plan and Markdown guidance.
