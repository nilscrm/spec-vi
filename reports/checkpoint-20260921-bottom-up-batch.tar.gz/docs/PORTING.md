# Vine porting workflow

## Evaluation first

Build an evaluator before scaling automated implementation. It must compile the pinned C++ reference and Vine candidate, compare intermediate and final states, measure depth/work/memory, and emit machine-readable results. Use valid small cases, increasing sizes, perturbed or clustered inputs where applicable, and multiple timesteps. Fix tolerances and work/memory budgets before judging optimization candidates.

For each component: dependency analysis -> candidate -> correctness -> depth scaling -> investigate avoidable dependencies -> integrated checks -> documentation update -> checkpoint. Continue with the next dependency-ready component.

## Measurement contract

The inspected Vine implementation maps --depth to breadth-first normalization; it counts rounds of active interactions. It selects this path before the worker execution path. Measure depth and actual parallel runtime in separate runs. Extrinsic operations are counted at runtime interaction granularity; depth is not a hardware cycle prediction.

Capture total interactions W, depth D, runtime heap statistics, process peak memory, numerical errors, and separate parallel timings. Minimize D subject to fixed correctness and resource constraints. W/D is descriptive, not an optimization objective on its own.

Use full state dumps for correctness. A depth driver must force every measured output using a validated, bounded-depth consumer; unused results may be erased. Account for input construction, output consumption, duplication, and cleanup. Do not blindly subtract standalone depths from total depth. Record kernel, full-timestep, and multi-timestep measurements because integration can add dependencies.

## Initial design hypotheses to test

- Balanced array construction and map/zip traversal can expose independent particle work.
- Balanced reductions can remove accumulator chains; floating-point reassociation requires a fixed numerical acceptance policy.
- Spatial subdivision may expose more parallel tree construction than serial insertion.
- Independent neighbor queries may still serialize through shared access. Compare partitioned traversal and controlled duplication with shared references, measuring work and memory as well as depth.
- Cross-timestep state dependencies are necessary; whole-dataset sequencing inside a particle-independent stage requires justification.

These are candidate strategies, not measured performance conclusions. The local Array implementation provides map_unordered, zip_with, and reduce_unordered with branching recursion; benchmark their compiled behavior and closure captures before relying on a depth bound.

## Learning and continuation

Apply the mandatory learning loop in AGENTS.md after each useful discovery. Maintain evidence in LESSONS.md, general techniques here, and benchmark-specific decisions beside the port. The runner in tools/runner.py independently reruns registered acceptance gates, preserves reports, limits Codex attempts and duration, and refuses completion when any required gate is absent or fails. See RUNNER.md. Numerical comparison, high-precision pilot snapshots, pilot depth/work/heap gates, and per-process peak-memory recording are implemented. Full-stage snapshots and hardware acceptance budgets remain pending. A real CLI worker preflight reaches the model but its nested tool sandbox fails; the visible scheduled follow-up continues code work directly in this task (RUNNER.md).

## Construction belongs in the cost model

A spatial hierarchy is not automatically an improvement: the first SPH neighbor candidate passed membership but had much higher depth than a scan (L012). Measure construction, repeated reductions, partition compaction and duplication. A serial-looking source accumulator may compile to a shallower graph than expected. Require actual compiled comparisons before choosing the representation.

## Measured representation guidance

Carry partition summaries with partition results to avoid repeated traversals (L014). Where operations are total and pure, compare eager boolean composition with short-circuit control; it can reduce dependencies but increase live memory. A true reduction identity can eliminate branches guarding empty values. Preserve strict geometric arithmetic and test boundaries when applying these transformations.

A shared root reference can serialize independent queries even when it lowers work: the SPH scan changed from depth506 to6661 at256 points (L015). Measure depth and work together. Batched routing is a hypothesis to evaluate, not an established solution.

## Batch queries without an ordered output merge

Independent result connections can preserve query identity while routing batches through one index (L016). This reduced repeated index work and met the SPH work-growth budget, but compacting dynamic request trees added depth. Compare both routing and compaction costs; retaining every empty branch can recover depth while losing work scaling. Keep construction in acceptance measurements, and treat prebuilt-index runs only as diagnostics.

A logically empty routed-request collection can still contain linear result-connection types. Resolve or explicitly drain those connections rather than relying on unsafe erasure (L017). Include this cleanup in performance measurements. Coarser compaction is not inherently faster: reject tiny depth gains that substantially increase work, even when one resource ceiling still passes.

Inspect hot scalar library calls before redesigning an algorithm around them. SPH radix construction exposed a bit-by-bit N32.leading_zeros loop (L018). A bounded binary search preserved semantics and lowered measured depth/work. Test zero and every power-of-two boundary plus independent random vectors, check all library callers, and repin root sources before integrated comparisons. Primitive improvements do not establish that the enclosing algorithm is competitive.

Measure field extraction and conversion when comparing array-of-records with separate coordinate trees. Independent scalar reductions may increase both depth and work (L019). Likewise, deferring summary calculation can save work/memory while lengthening the critical path; use matched fully forced outputs before integrating either representation.

A local compaction dependency may prevent far greater work downstream. SPH point partitions became shallower without compaction, yet the full recursive pipeline became deeper and performed nearly12x the work (L020). Always measure repeated consumers before retaining a local structural optimization. Cached counts are not automatically a faster substitute for inspecting constructors.

Use preordered-input diagnostics to distinguish spatial-locality work costs from routing depth, but label all excluded preprocessing explicitly. Improved locality need not reduce the critical path (L021); a faster index builder alone cannot establish shallow query routing.
