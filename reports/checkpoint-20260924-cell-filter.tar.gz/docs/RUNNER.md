# Runner operation

## What is installed

`tools/runner.py` is a local background milestone supervisor. It executes acceptance gates in order and updates `STATUS.md`, `reports/status.json`, and `reports/runs/<run-id>/status.json`. Each gate preserves argv, working directory, exit status, duration, stdout, stderr, and an evaluation report. The bootstrap gate verifies unchanged upstream sources, runs infrastructure tests and C++ smoke cases, and checks Vine depth and worker execution separately.

This bootstrap is not a SPH-EXA Vine implementation. The pilot gate passes; the registered neighbor gate currently rejects the spatial-tree candidate on depth/work scaling. Do not register a passing placeholder to advance it.

## Commands

From `~/repos/spec-vi`:

- `make start`: background acceptance run.
- `make run`: foreground acceptance run.
- `make status`: current status, including stale-process detection.
- `make watch`: refresh every two seconds while running; exits on terminal/waiting state.
- `make stop`: stop the active runner and its gate process group.
- `make test`: infrastructure tests, with no model calls.
- `python3 tools/runner.py status --json`: machine-readable status.

Only one runner can hold the lock. Repeated starts are refused while active. A new run rechecks earlier gates, which avoids trusting results for changed source. Reports from earlier runs remain available.

## Optional code-writing mode

`python3 tools/runner.py start --port --max-attempts 3 --agent-timeout 1200`

This may invoke Codex and consume usage, but only for a failed milestone that already has both a real gate and a worker prompt. Missing gates still stop the run. The default `make start` never invokes Codex. A real code-writing preflight was attempted on 2026-09-20. Model connectivity works, but nested tool sandbox startup fails inside this desktop task. Do not retry --port here until that environment issue is resolved; the scheduled task continues implementation directly and uses the runner for acceptance.

Codex runs with the user's configured model, workspace-write sandbox, existing CLI authentication, and no sandbox bypass. This directory currently has no Git metadata, so the invocation uses the documented --skip-git-repo-check option. No Git checkpoints are currently created; immutable run directories preserve evidence, not full working-tree rollback snapshots. Establish Git before long autonomous code-writing runs.

The worker reads docs/WORKER_PROMPT.md plus current failure evidence and writes an informational structured report. The supervisor reruns the gate itself. A worker's completion claim never overrides a failed gate. Changes to upstream sources, evaluations/, or the evaluator during worker execution stop acceptance for review. Each attempt is time-limited; failures stop after the configured attempt count. The visible Continue SPH-EXA Vine port heartbeat continues this task every30 minutes; it does not blindly restart a failing nested worker.

## Status meanings

- `running`: a runner holds the lock and is checking or implementing the named milestone.
- `waiting`: a required acceptance check is missing. No background work continues.
- `failed`: a command, numerical check, resource deadline, or acceptance report failed.
- `stopped` / `interrupted`: unfinished work remains; inspect evidence before resuming.
- `complete`: ALL required registered milestones passed independent gates. The required list includes full selected workloads and hardware validation.

`port_complete` is separate from individual passed checks. The runner cannot establish scientific validity by itself: gate coverage, tolerances, and depth/resource budgets must be sound before registration. It rejects omitted required milestones, missing/false/wrong reports, and stale output reports.

## Notifications and limits

Completion and failure update the local status and runner log. `make watch` exits visibly with the final status. The Continue SPH-EXA Vine port heartbeat is installed in this task and checks every30 minutes. It continues actionable porting work directly and reports meaningful progress or blockers. Check its automation card for active/paused state.

Bootstrap uses the existing Vine release binary and records its hash plus checkout evidence; a matching build from the dirty checkout is not established. The scalar diagnostic exercises the metrics pipeline, not a SPH kernel. Reference smoke dumps use upstream's default output precision. High-precision pilot snapshots, complete pilot output consumption, and process RSS are implemented. Full evolution and target-hardware timings remain unvalidated. Source checkpoint archives and isolated Vine patches preserve current work while signed Git checkpoints remain pending.
