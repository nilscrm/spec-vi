# SPH-EXA execution plan

## Status

- Done: pinned unchanged upstream, source manifest, serial C++ build and smoke run.
- Done: persistent workflow and mandatory documentation learning loop.
- Done: local status runner, bootstrap gate, table comparator, stats parser, and runtime diagnostic probe.
- Done: high-precision initialization/density pilot on sides 12 and 16, fixed correctness/depth/work/heap budgets. Evidence: reports/runs/20260915T161128Z-45040/pilot/.
- Done: bounded optional worker dispatch and independent re-verification tests; real CLI startup/tool-sandbox limitation documented in L013.
- Neighbor gate is registered. Initial candidate passes membership but fails depth/work scaling (L012); runner status is authoritative for worker activity.

## Toolchain transition

work/vine-lookup is the isolated lookup-based checkout with tested scalar sine/pi and large bounded lookup additions. Main Vine and stashes remain untouched. Support changes are staged; signed commits were blocked by unavailable GPG agent access. Preserve patches and exact source/binary hashes until checkpoint signing is available.

## Next action

Measure dynamic immutable indexed reads as a prerequisite for direct spatial-cell access. Compare runtime-built copied-value selection and Array reference-based reads at64/256 elements and growing query counts, forcing and validating every output while including construction/copy/cleanup. Inspect existing APIs before extending Vine: Lookup is static; Array.get uses a reference. Avoid fixture-specific particle tables. Use this experiment to decide whether a reusable dynamic-read capability is needed before implementing a grid. Do not continue minor group-size sweeps: groups8/32 barely changed depth (L022). No neighbor milestone is accepted; all budgets remain fixed.

## Milestones

1. Evaluator: fixed valid cases, numerical policy, structured results, resource limits, depth driver that forces all outputs, separate parallel timing.
2. Initialization and density pilot: full dependency argument, C++ comparisons, multiple input sizes, measured alternative formulations, learned guidance updates.
3. Octree construction and neighbor search: brute-force small-case oracle plus upstream sets/order comparison; clustered and boundary cases.
4. Density, equation of state, IAD, momentum/energy, timestep selection, position update, total energy. Implement prerequisites needed for the density pilot before claiming the pilot complete.
5. Integrated update and multiple updates: intermediate states, error growth, depth/work/memory scaling.
6. Reconstruct documented SPEC-like driver/output behavior, keeping unresolved differences explicit.
7. Full selected workload validation and parallel hardware measurements. Record any workloads not executed; do not call the full port validated without them.
8. Enable unattended milestone execution only after the pilot demonstrates reliable evaluator acceptance and checkpoint recovery.

For each milestone record candidate, evidence paths, numerical results, depth/work/memory, dependency rationale, changed Markdown files (or no new lessons), and next action. Reopen affected completed components when new evidence invalidates assumptions.

## Continuation status (2026-09-20)

Pilot revalidated with separate two-worker runs: reports/runs/20260920T180935Z-79500/pilot/result.json. Neighbor membership passes but depth/work gates fail. A real nested CLI worker cannot start its tool sandbox; no CLI implementation worker is active. Continue directly in the existing Codex task via the installed30-minute heartbeat; run acceptance without --port. Do not keep retrying nested workers or relax sandboxing. Next: isolate bounds/partition/copying costs and compare simpler eager-predicate representations. Preserve the failure and unchanged budgets.

## Latest completed experiment cycle

Cached partition summaries, empty-bounds identities and eager pure predicates are retained in neighbors.vi. Fixed membership cases and five additional degenerate/random cases pass; the pilot regression and17 infrastructure/oracle tests pass. Neighbor depth/work gates still fail; no milestone was advanced. Reproduction and alternatives: reports/neighbors/followup-1/, reports/neighbors/eager-cached-validation/, reports/neighbors/eager-cached-extra/, reports/pilot/neighbor-followup-regression/. Source checkpoint: reports/checkpoint-20260920-neighbor-followup.tar.gz. Continue from L014–L015 and the Next action above; do not reset to the original hierarchy.

## Scheduled experiment cycle (2026-09-21)

Completed compacted and uncompacted batch routing, matched-library controls, exact membership checks, extra edge/random checks, separate two-worker checks and query-only diagnostics. No production/shared code or acceptance inputs changed, so no pilot rerun was needed. Toolchain pin and unchanged production source were verified. Evidence: reports/neighbors/batch-routing/{result,controls,extra-checks,query-only,budget-review}.json and the uncompacted sibling. No milestone advanced; follow L016 and Next action.

## Scheduled cycle: grouped compaction rejected

Four occupancy/compaction variants were implemented and measured on full64/256 membership and depth workloads. Construction and bounds diagnostics were added. All variants are rejected; no production/shared files changed and no gate was re-registered. Reproduction: reports/neighbors/tiled-routing/run.py and construction.py; conclusions in L017. Do not spend another cycle on the same compaction sweep.


## Scheduled cycle: spatial builders and root bit count

Radix, radix buckets and independent coarse buckets were implemented, measured and rejected (L018). A reusable five-step N32.leading_zeros change was retained in isolated Vine with1118 independent vectors and affected N64/Nat/F64 regressions. Actual root batches match the prototype:1118 words D377->216, W286129->56217, heap253488->579584 bytes. The dependency pin is validated by reports/runs/20260921T190441Z-95573: bootstrap/pilot pass, all eight neighbor membership cases pass, unchanged neighbor depth/work failures remain. Root patch and previous pin are preserved; signed commits remain pending. Proceed with Next action, not another pin-validation cycle.


## Scheduled cycle: bounds layouts and partition summaries

Completed exact bounds/identity and matched depth diagnostics at64/256; both separate-coordinate representations and deferred summaries lose depth. Evidence: reports/neighbors/bounds-layout/, L019. Production, dependency and gates remain unchanged; no integrated rerun needed. Continue from Next action.


## Scheduled cycle: point-branch compaction

Completed exact diagnostic comparisons and full eight-case membership/depth/worker evaluations of preserved branches and cached-count joins. Both lose full-pipeline performance despite the preserved-branch component depth gain. Evidence: reports/neighbors/point-branches/, L020. Production and dependency unchanged; no pilot rerun needed. Checkpoint: reports/checkpoint-20260921-point-branches.tar.gz.


## Scheduled cycle: bottom-up construction with batching

Leaf and bucket variants pass all eight memberships and worker checks but fail depth/work budgets. Spatially ordered-input diagnostic isolates locality and explicitly excludes host sorting; it is not acceptance evidence. Reports: reports/neighbors/bottom-up-batch/, L021. Production/root/gates unchanged; checkpoint reports/checkpoint-20260921-bottom-up-batch.tar.gz.


## Scheduled cycle: independent query groups

Groups8/32 pass exact membership and worker checks, with only1.6–1.9% depth improvement and continued depth failure. Matched full-batch/single-query controls pass. Reports: reports/neighbors/query-groups/, L022. No shared code changed. Checkpoint: reports/checkpoint-20260921-query-groups.tar.gz.
